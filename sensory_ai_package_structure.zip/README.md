# Sensory AI

A sensory-based AI simulation engine supporting multi-organism embodiment, internal physiology, and LLM integration. Ideal for games, embodied agents, and reasoning simulations.

## Features
- Human/animal/plant/insect/fish simulation
- Reproduction, DNA identity, organ health
- Priority-based thought/action decision
- Sensor fatigue, memory, and skill learning
- Supports grounding for LLMs (like ChatGPT)

## Install
```bash
pip install sensory_ai
```
