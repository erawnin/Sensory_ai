# sensory_ai/engine.py
def test():
    return "Sensory engine initialized."
