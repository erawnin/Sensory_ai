
from setuptools import setup, find_packages

setup(
    name="sensory_ai",
    version="0.1.0",
    author="Erawnin",
    description="Sensory-based AI engine with LLM integration support",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/Erawnin/sensory_ai",
    packages=find_packages(),
    install_requires=[],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.7',
)
